# React 模仿大众点评

如果是 windows 系统，请将`./package.json`里面的`NODE_ENV=dev`全部修改为`set NODE_ENV=dev`

运行程序

`npm install`
`npm run mock`
set NODE_ENV=dev
`npm start`

另外，所有的后端接口地址，都可以在`./mock/server.js`中查看

